# Analisador sintático LALG

Este é um analisador sintático desenvolvido como projeto final para a disciplina de Compiladores da USP.

Alunos:
Bárbara Côrtes e Souza 					(nº USP 9763050)
David Souza Rodrigues 					(nº USP 4461180)
Gabriel Toschi de Oliveira 				(nº USP 9763039)
Lucas Fernandes Turci 					(nº USP 9763085)
Marcos Wendell Souza de Oliveira Santos (nº USP 9791351)

Docente:
Diego Raphael Amancio

##Como utilizar?

Para usar o programa, rode o executável pelo comando `./analisador-sintatico`.
Este programa irá, por sua vez, executar o Makefile presente no mesmo diretório, que irá compilar os programas responsáveis pela análise léxica e sintática, que usam as ferramentas lex e yacc.
Portanto, é preciso que os seguintes arquivos

- codes.txt
- tables.cpp
- trab2.l
- trab2.y
- Makefile

estejam presentes no mesmo diretório do programa, assim como as bibliotecas e shared objects utilizados para a interface gráfica.
